Item statistics
===============

  * `com.cloudbees.opscenter.server.model.ClientMaster`
    - Number of items: 1

Total job statistics
======================

  * Number of jobs: 0
  * Number of builds per job: N/A
