Monitors
========

`com.cloudbees.jenkins.plugins.administrative_monitors.SystemJvmMonitor`
--------------
(active and enabled)

`com.cloudbees.jenkins.plugins.advisor.Reminder`
--------------
(active and enabled)

`com.cloudbees.jenkins.plugins.assurance.UpgradesWatch`
--------------
(active and enabled)

`com.cloudbees.jenkins.plugins.license.nectar.ExecutorOverage`
--------------
(active and enabled)

`jenkins.diagnostics.ControllerExecutorsNoAgents`
--------------
(active and enabled)

`jenkins.diagnostics.URICheckEncodingMonitor`
--------------
(active and enabled)

`jenkins.model.BuiltInNodeMigration`
--------------
(active and enabled)

`org.jenkinsci.plugins.useractivity.dao.H2MigrationMonitor`
--------------
(active and enabled)
