Node monitors
=============
Approved Folders
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: null
Architecture
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: Linux (amd64)
Clock Difference
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: In sync
Free Disk Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * Built-In Node: 43.834GB left on /mnt/nfsocfile/cloudbees-core-oc.
Free Swap Space
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: Memory:5950/16019MB  Swap:0/0MB
Free Temp Space
----
 - Is Ignored: false
 - Threshold: 1GB
 - Computers:
   * Built-In Node: 4.526GB left on /tmp/tmp.IW4VAWSbJA.
Response Time
----
 - Is Ignored: false
 - Computers:
   * Built-In Node: 0ms
