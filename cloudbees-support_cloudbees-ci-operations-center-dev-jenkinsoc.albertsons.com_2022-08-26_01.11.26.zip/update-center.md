=== Sites ===
 - Id: core-oc-traditional-offline
 - Url: file:/var/cache/cloudbees-core-oc/war/WEB-INF/plugins/update-center.json
 - Connection Url: file:/var/cache/cloudbees-core-oc/war/WEB-INF/plugins/update-center.json
 - Implementation Type: com.cloudbees.jenkins.plugins.license.nectar.OfflineUpdateSite
 - Id: cap-core-oc-traditional
 - Url: https://jenkins-updates.cloudbees.com/update-center/envelope-core-oc-traditional/update-center.json
 - Connection Url: null
 - Implementation Type: com.cloudbees.jenkins.plugins.license.nectar.CloudBeesUpdateSite
======
Last updated: 1 day 2 hr
=== Proxy ===
