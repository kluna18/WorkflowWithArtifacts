Jenkins
=======

Version details
---------------

  * Version: `2.346.3.4`
  * Instance ID: `2d0aa375a9d088cf9b9d533a2b3a384d`
  * Mode:    WAR
  * Url:     https://dev-jenkinsoc.albertsons.com/
  * Servlet container
      - Specification: 3.1
      - Name:          `jetty/9.4.45.v20220203`
  * Java
      - Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre`
      - Vendor:           Red Hat, Inc.
      - Version:          1.8.0&#95;342
      - Maximum memory:   3.48 GB (3733979136)
      - Allocated memory: 261.00 MB (273678336)
      - Free memory:      40.07 MB (42012512)
      - In-use memory:    220.93 MB (231665824)
      - GC strategy:      ParallelGC
      - Available CPUs:   4
  * Java Runtime Specification
      - Name:    Java Platform API Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Specification
      - Name:    Java Virtual Machine Specification
      - Vendor:  Oracle Corporation
      - Version: 1.8
  * JVM Implementation
      - Name:    OpenJDK 64-Bit Server VM
      - Vendor:  Red Hat, Inc.
      - Version: 25.342-b07
  * Operating system
      - Name:         Linux
      - Architecture: amd64
      - Version:      4.18.0-372.16.1.el8&#95;6.x86&#95;64
  * Process ID: 1706042 (0x1a083a)
  * Process started: 2022-08-16 22:46:32.821+0000
  * Process uptime: 9 days 2 hr
  * JVM startup parameters:
      - Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/classes`
      - Classpath: `/usr/lib/cloudbees-core-oc/cloudbees-core-oc.war`
      - Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
      - arg[0]: `-Dcb.distributable.name=RedHat / Fedora RPM`
      - arg[1]: `-Dcb.distributable.commit_sha=412639d3273d58ef8387e711adb8f9882e47edd4`
      - arg[2]: `-Djava.io.tmpdir=/tmp/tmp.IW4VAWSbJA`
      - arg[3]: `-Djava.awt.headless=true`
      - arg[4]: `-Duser.timezone=America/Los_Angeles`
      - arg[5]: `-Dhudson.TcpSlaveAgentListener.hostName=172.25.35.26`

Remoting details
---------------

  * Embedded Version: `4.13.3`
  * Minimum Supported Version: `3.14`

Important configuration
---------------

  * Security realm: `org.jenkinsci.plugins.saml.SamlSecurityRealm`
  * Authorization strategy: `hudson.security.FullControlOnceLoggedInAuthorizationStrategy`
  * CSRF Protection: true
  * Initialization Milestone: Completed initialization
  * Support bundle anonymization: false

Active Plugins
--------------

  * ace-editor:1.1 'JavaScript GUI Lib: ACE Editor bundle plugin'
  * antisamy-markup-formatter:2.7 'OWASP Markup Formatter Plugin'
  * apache-httpcomponents-client-4-api:4.5.13-1.0 'Jenkins Apache HttpComponents Client 4.x API Plugin'
  * async-http-client:1.7.24.3 'Async Http Client'
  * aws-credentials:191.vcb_f183ce58b_9 'CloudBees AWS Credentials Plugin'
  * aws-java-sdk:1.11.995 'Amazon Web Services SDK'
  * aws-java-sdk-ec2:1.12.246-349.v96b_b_f7eb_a_c3c 'Amazon Web Services SDK :: EC2'
  * aws-java-sdk-minimal:1.12.246-349.v96b_b_f7eb_a_c3c 'Amazon Web Services SDK :: Minimal'
  * bootstrap4-api:4.6.0-5 'Bootstrap 4 API Plugin'
  * bootstrap5-api:5.1.3-7 'Bootstrap 5 API Plugin'
  * bouncycastle-api:2.26 'bouncycastle API Plugin'
  * caffeine-api:2.9.3-65.v6a_47d0f4d1fe 'Caffeine API Plugin'
  * checks-api:1.7.4 'Checks API plugin'
  * cloudbees-administrative-monitors:1.0.4 'CloudBees Administrative Monitors Plugin'
  * cloudbees-analytics:1.42 'CloudBees Analytics Plugin'
  * cloudbees-assurance:2.276.0.23 'Beekeeper Upgrade Assistant Plugin'
  * cloudbees-casc-server:1.77 'CloudBees CasC Server Plugin'
  * cloudbees-folder:6.729.v2b_9d1a_74d673 'Folders Plugin'
  * cloudbees-folders-plus:3.28 'CloudBees Folders Plus Plugin'
  * cloudbees-ha:4.39 'CloudBees High Availability Management plugin'
  * cloudbees-jenkins-advisor:3.3.2 'Jenkins Health Advisor by CloudBees'
  * cloudbees-license:9.68 'CloudBees License Manager'
  * cloudbees-monitoring:2.14 'CloudBees Monitoring Plugin'
  * cloudbees-platform-common:1.17 'CloudBees Platform Common Plugin'
  * cloudbees-platform-data:1.27 'CloudBees Unified Data Plugin'
  * cloudbees-plugin-usage:2.15 'CloudBees Plugin Usage Analyzer Plugin'
  * cloudbees-ssh-slaves:2.18 'CloudBees SSH Build Agents Plugin'
  * cloudbees-support:3.29 'CloudBees Support Plugin'
  * cloudbees-uc-data-api:4.50 'CloudBees Update Center Data API'
  * cloudbees-unified-ui:1.21 'CloudBees Unified UI Plugin'
  * cloudbees-update-center-plugin:4.71 'CloudBees Update Center Plugin'
  * command-launcher:84.v4a_97f2027398 'Command Agent Launcher Plugin'
  * credentials:1129.vef26f5df883c 'Credentials Plugin'
  * credentials-binding:523.vd859a_4b_122e6 'Credentials Binding Plugin'
  * display-url-api:2.3.6 'Display URL API'
  * durable-task:496.va67c6f9eefa7 'Durable Task Plugin'
  * echarts-api:5.3.3-1 'ECharts API Plugin'
  * font-awesome-api:6.1.1-1 'Font Awesome API Plugin'
  * git-client:3.11.1 'Jenkins Git client plugin'
  * handy-uri-templates-2-api:2.1.8-22.v77d5b_75e6953 'Handy Uri Templates 2.x API Plugin'
  * infradna-backup:3.38.52 'CloudBees Backup Plugin'
  * jackson2-api:2.13.3-285.vc03c0256d517 'Jackson 2 API Plugin'
  * javax-activation-api:1.2.0-4 'JavaBeans Activation Framework (JAF) API'
  * javax-mail-api:1.6.2-6 'JavaMail API'
  * jaxb:2.3.6-1 'JAXB plugin'
  * jdk-tool:1.5 'Oracle Java SE Development Kit Installer Plugin'
  * jjwt-api:0.11.5-77.v646c772fddb_0 'Java JSON Web Token (JJWT) Plugin'
  * jquery-detached:1.2.1 'JavaScript GUI Lib: jQuery bundles (jQuery and jQuery UI) plugin'
  * jquery3-api:3.6.0-4 'JQuery3 API Plugin'
  * jsch:0.1.55.2 'Jenkins JSch dependency plugin'
  * junit:1119.1121.vc43d0fc45561 'JUnit Plugin'
  * ldap:2.10 'LDAP Plugin'
  * mailer:414.vcc4c33714601 'Jenkins Mailer Plugin'
  * mapdb-api:1.0.9.0 'MapDB API Plugin'
  * matrix-project:772.v494f19991984 'Matrix Project Plugin'
  * metrics:4.1.6.2 'Metrics Plugin'
  * nectar-license:8.41 'CloudBees Jenkins Enterprise License Entitlement Check'
  * nectar-rbac:5.75 'CloudBees Role-Based Access Control Plugin'
  * node-iterator-api:1.5.1 'Node Iterator API Plugin'
  * okhttp-api:4.9.2-20211102 'OkHttp Plugin'
  * operations-center-agent:2.346.0.2 'Operations Center Agent'
  * operations-center-clusterops:2.346.0.2 'Operations Center Server Cluster Operations'
  * operations-center-context:2.346.0.8 'Operations Center Context'
  * operations-center-jnlp-controller:2.346.0.3 'Operations Center JNLP Agent Controller Plugin'
  * operations-center-license:2.346.0.3 'Operations Center Server License Entitlement Check'
  * operations-center-monitoring:2.346.0.2 'Operations Center Monitoring Plugin'
  * operations-center-rbac:2.346.0.2 'Operations Center Server Role Based Access Control'
  * operations-center-server:2.346.0.5 'Operations Center Server Plugin'
  * operations-center-sso:2.346.0.2 'Operations Center Single Sign-On Plugin'
  * operations-center-updatecenter:2.346.0.2 'Operations Center Update Center Plugin'
  * plain-credentials:1.8 'Plain Credentials Plugin'
  * plugin-util-api:2.17.0 'Plugin Utilities API Plugin'
  * popper-api:1.16.1-3 'Popper.js API Plugin'
  * popper2-api:2.11.5-2 'Popper.js 2 API Plugin'
  * saml:2.298.vc7a_2b_3958628 'SAML Plugin'
  * scm-api:608.vfa_f971c5a_a_e9 'SCM API Plugin'
  * script-security:1175.v4b_d517d6db_f0 'Script Security Plugin'
  * snakeyaml-api:1.30.2-76.vc104f7ce9870 'SnakeYAML API Plugin'
  * ssh-credentials:291.v8211e4f8efb_c 'SSH Credentials Plugin'
  * sshd:3.237.v883d165a_c1d3 'SSH server'
  * structs:318.va_f3ccb_729b_71 'Structs Plugin'
  * support-core:1201.v8d1f54a_6ec7c 'Support Core Plugin'
  * suppress-stack-trace:1.6 'Stack Trace Suppression Plugin (deprecated)'
  * token-macro:293.v283932a_0a_b_49 'Token Macro Plugin'
  * trilead-api:1.67.vc3938a_35172f 'Trilead API Plugin'
  * user-activity-monitoring:1.7 'User Activity Monitoring Plugin'
  * variant:1.4 'Variant Plugin'
  * workflow-api:1188.v0016b_4f29881 'Pipeline: API'
  * workflow-step-api:625.vd896b_f445a_f8 'Pipeline: Step API'
  * workflow-support:827.v7ef666c4d65c 'Pipeline: Supporting APIs'

Packaging details
-----------------

#UNKNOWN#

CloudBees Product Description
-----------------------------


CloudBees Distributable Description
-----------------------------------

 * Distributable Name: RedHat / Fedora RPM
 * UDR Commit SHA: 412639d3273d58ef8387e711adb8f9882e47edd4

License details
---------------

 * Jenkins Instance ID:  `2d0aa375a9d088cf9b9d533a2b3a384d`
 * Expires:              2022-12-29 23:59:59.000+0000
 * Issued to:            Safeway
 * Organization:         safeway
     - Team Management
     - Security
     - Analytics
     - Core
     - Build & Master Resilience
     - Optimized Utilization
     - Enterprise Management
     - CloudBees Jenkins Enterprise license with 5 executors
     - Operations Center server license with sub-licensing for 0 client masters and 3 test client masters
