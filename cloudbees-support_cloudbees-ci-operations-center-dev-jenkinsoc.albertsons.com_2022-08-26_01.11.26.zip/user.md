User
====

Authentication
--------------

  * Authenticated: true
  * Name: kluna18@safeway.com
  * Authorities 
      - `authenticated`

