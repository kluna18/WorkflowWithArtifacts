# Configuration

WAR Envelope detected [core-oc-traditional-2.346.3.4]
Installed Envelope detected [core-oc-traditional-2.346.3.4]
CloudBees Assurance Program enabled: true
Allow automatic upgrades of individual plugins on startup: false
Allow automatic downgrades of individual plugins on startup: false
Notify when security warnings affecting the core are detected: true
Notify when security warnings affecting plugins are detected: true

# Report

SUCCESS - Beekeeper Upgrade Assistant enabled on version 2.346.3.4.

## Items Requiring Attention

## Valid Items

* PLUGIN OWASP Markup Formatter Plugin (antisamy-markup-formatter)
    * Description: Correctly installed at version 2.7
    * Action: No action needed.

* PLUGIN Jenkins Apache HttpComponents Client 4.x API Plugin (apache-httpcomponents-client-4-api)
    * Description: Correctly installed at version 4.5.13-1.0
    * Action: No action needed.

* PLUGIN CloudBees AWS Credentials Plugin (aws-credentials)
    * Description: Correctly installed at version 191.vcb_f183ce58b_9
    * Action: No action needed.

* PLUGIN Amazon Web Services SDK :: EC2 (aws-java-sdk-ec2)
    * Description: Correctly installed at version 1.12.246-349.v96b_b_f7eb_a_c3c
    * Action: No action needed.

* PLUGIN Amazon Web Services SDK :: Minimal (aws-java-sdk-minimal)
    * Description: Correctly installed at version 1.12.246-349.v96b_b_f7eb_a_c3c
    * Action: No action needed.

* PLUGIN Bootstrap 4 API Plugin (bootstrap4-api)
    * Description: Correctly installed at version 4.6.0-5
    * Action: No action needed.

* PLUGIN Bootstrap 5 API Plugin (bootstrap5-api)
    * Description: Correctly installed at version 5.1.3-7
    * Action: No action needed.

* PLUGIN bouncycastle API Plugin (bouncycastle-api)
    * Description: Correctly installed at version 2.26
    * Action: No action needed.

* PLUGIN Caffeine API Plugin (caffeine-api)
    * Description: Correctly installed at version 2.9.3-65.v6a_47d0f4d1fe
    * Action: No action needed.

* PLUGIN Checks API plugin (checks-api)
    * Description: Correctly installed at version 1.7.4
    * Action: No action needed.

* PLUGIN CloudBees Administrative Monitors Plugin (cloudbees-administrative-monitors)
    * Description: Correctly installed at version 1.0.4
    * Action: No action needed.

* PLUGIN CloudBees Analytics Plugin (cloudbees-analytics)
    * Description: Correctly installed at version 1.42
    * Action: No action needed.

* PLUGIN Beekeeper Upgrade Assistant Plugin (cloudbees-assurance)
    * Description: Correctly installed at version 2.276.0.23
    * Action: No action needed.

* PLUGIN CloudBees CasC Server Plugin (cloudbees-casc-server)
    * Description: Correctly installed at version 1.77
    * Action: No action needed.

* PLUGIN Folders Plugin (cloudbees-folder)
    * Description: Correctly installed at version 6.729.v2b_9d1a_74d673
    * Action: No action needed.

* PLUGIN CloudBees Folders Plus Plugin (cloudbees-folders-plus)
    * Description: Correctly installed at version 3.28
    * Action: No action needed.

* PLUGIN CloudBees High Availability Management plugin (cloudbees-ha)
    * Description: Correctly installed at version 4.39
    * Action: No action needed.

* PLUGIN Jenkins Health Advisor by CloudBees (cloudbees-jenkins-advisor)
    * Description: Correctly installed at version 3.3.2
    * Action: No action needed.

* PLUGIN CloudBees License Manager (cloudbees-license)
    * Description: Correctly installed at version 9.68
    * Action: No action needed.

* PLUGIN CloudBees Monitoring Plugin (cloudbees-monitoring)
    * Description: Correctly installed at version 2.14
    * Action: No action needed.

* PLUGIN CloudBees Platform Common Plugin (cloudbees-platform-common)
    * Description: Correctly installed at version 1.17
    * Action: No action needed.

* PLUGIN CloudBees Unified Data Plugin (cloudbees-platform-data)
    * Description: Correctly installed at version 1.27
    * Action: No action needed.

* PLUGIN CloudBees Plugin Usage Analyzer Plugin (cloudbees-plugin-usage)
    * Description: Correctly installed at version 2.15
    * Action: No action needed.

* PLUGIN CloudBees SSH Build Agents Plugin (cloudbees-ssh-slaves)
    * Description: Correctly installed at version 2.18
    * Action: No action needed.

* PLUGIN CloudBees Support Plugin (cloudbees-support)
    * Description: Correctly installed at version 3.29
    * Action: No action needed.

* PLUGIN CloudBees Update Center Data API (cloudbees-uc-data-api)
    * Description: Correctly installed at version 4.50
    * Action: No action needed.

* PLUGIN CloudBees Unified UI Plugin (cloudbees-unified-ui)
    * Description: Correctly installed at version 1.21
    * Action: No action needed.

* PLUGIN CloudBees Update Center Plugin (cloudbees-update-center-plugin)
    * Description: Correctly installed at version 4.71
    * Action: No action needed.

* PLUGIN Command Agent Launcher Plugin (command-launcher)
    * Description: Correctly installed at version 84.v4a_97f2027398
    * Action: No action needed.

* PLUGIN Credentials Plugin (credentials)
    * Description: Correctly installed at version 1129.vef26f5df883c
    * Action: No action needed.

* PLUGIN Credentials Binding Plugin (credentials-binding)
    * Description: Correctly installed at version 523.vd859a_4b_122e6
    * Action: No action needed.

* PLUGIN Display URL API (display-url-api)
    * Description: Correctly installed at version 2.3.6
    * Action: No action needed.

* PLUGIN Durable Task Plugin (durable-task)
    * Description: Correctly installed at version 496.va67c6f9eefa7
    * Action: No action needed.

* PLUGIN ECharts API Plugin (echarts-api)
    * Description: Correctly installed at version 5.3.3-1
    * Action: No action needed.

* PLUGIN Font Awesome API Plugin (font-awesome-api)
    * Description: Correctly installed at version 6.1.1-1
    * Action: No action needed.

* PLUGIN Jenkins Git client plugin (git-client)
    * Description: Correctly installed at version 3.11.1
    * Action: No action needed.

* PLUGIN Handy Uri Templates 2.x API Plugin (handy-uri-templates-2-api)
    * Description: Correctly installed at version 2.1.8-22.v77d5b_75e6953
    * Action: No action needed.

* PLUGIN CloudBees Backup Plugin (infradna-backup)
    * Description: Correctly installed at version 3.38.52
    * Action: No action needed.

* PLUGIN Jackson 2 API Plugin (jackson2-api)
    * Description: Correctly installed at version 2.13.3-285.vc03c0256d517
    * Action: No action needed.

* PLUGIN JavaBeans Activation Framework (JAF) API (javax-activation-api)
    * Description: Correctly installed at version 1.2.0-4
    * Action: No action needed.

* PLUGIN JavaMail API (javax-mail-api)
    * Description: Correctly installed at version 1.6.2-6
    * Action: No action needed.

* PLUGIN JAXB plugin (jaxb)
    * Description: Correctly installed at version 2.3.6-1
    * Action: No action needed.

* PLUGIN Oracle Java SE Development Kit Installer Plugin (jdk-tool)
    * Description: Correctly installed at version 1.5
    * Action: No action needed.

* PLUGIN Java JSON Web Token (JJWT) Plugin (jjwt-api)
    * Description: Correctly installed at version 0.11.5-77.v646c772fddb_0
    * Action: No action needed.

* PLUGIN JQuery3 API Plugin (jquery3-api)
    * Description: Correctly installed at version 3.6.0-4
    * Action: No action needed.

* PLUGIN Jenkins JSch dependency plugin (jsch)
    * Description: Correctly installed at version 0.1.55.2
    * Action: No action needed.

* PLUGIN JUnit Plugin (junit)
    * Description: Correctly installed at version 1119.1121.vc43d0fc45561
    * Action: No action needed.

* PLUGIN LDAP Plugin (ldap)
    * Description: Correctly installed at version 2.10
    * Action: No action needed.

* PLUGIN Jenkins Mailer Plugin (mailer)
    * Description: Correctly installed at version 414.vcc4c33714601
    * Action: No action needed.

* PLUGIN MapDB API Plugin (mapdb-api)
    * Description: Correctly installed at version 1.0.9.0
    * Action: No action needed.

* PLUGIN Matrix Project Plugin (matrix-project)
    * Description: Correctly installed at version 772.v494f19991984
    * Action: No action needed.

* PLUGIN Metrics Plugin (metrics)
    * Description: Correctly installed at version 4.1.6.2
    * Action: No action needed.

* PLUGIN CloudBees Jenkins Enterprise License Entitlement Check (nectar-license)
    * Description: Correctly installed at version 8.41
    * Action: No action needed.

* PLUGIN CloudBees Role-Based Access Control Plugin (nectar-rbac)
    * Description: Correctly installed at version 5.75
    * Action: No action needed.

* PLUGIN Node Iterator API Plugin (node-iterator-api)
    * Description: Correctly installed at version 1.5.1
    * Action: No action needed.

* PLUGIN OkHttp Plugin (okhttp-api)
    * Description: Correctly installed at version 4.9.2-20211102
    * Action: No action needed.

* PLUGIN Operations Center Agent (operations-center-agent)
    * Description: Correctly installed at version 2.346.0.2
    * Action: No action needed.

* PLUGIN Operations Center Server Cluster Operations (operations-center-clusterops)
    * Description: Correctly installed at version 2.346.0.2
    * Action: No action needed.

* PLUGIN Operations Center Context (operations-center-context)
    * Description: Correctly installed at version 2.346.0.8
    * Action: No action needed.

* PLUGIN Operations Center JNLP Agent Controller Plugin (operations-center-jnlp-controller)
    * Description: Correctly installed at version 2.346.0.3
    * Action: No action needed.

* PLUGIN Operations Center Server License Entitlement Check (operations-center-license)
    * Description: Correctly installed at version 2.346.0.3
    * Action: No action needed.

* PLUGIN Operations Center Monitoring Plugin (operations-center-monitoring)
    * Description: Correctly installed at version 2.346.0.2
    * Action: No action needed.

* PLUGIN Operations Center Server Role Based Access Control (operations-center-rbac)
    * Description: Correctly installed at version 2.346.0.2
    * Action: No action needed.

* PLUGIN Operations Center Server Plugin (operations-center-server)
    * Description: Correctly installed at version 2.346.0.5
    * Action: No action needed.

* PLUGIN Operations Center Single Sign-On Plugin (operations-center-sso)
    * Description: Correctly installed at version 2.346.0.2
    * Action: No action needed.

* PLUGIN Operations Center Update Center Plugin (operations-center-updatecenter)
    * Description: Correctly installed at version 2.346.0.2
    * Action: No action needed.

* PLUGIN Plain Credentials Plugin (plain-credentials)
    * Description: Correctly installed at version 1.8
    * Action: No action needed.

* PLUGIN Plugin Utilities API Plugin (plugin-util-api)
    * Description: Correctly installed at version 2.17.0
    * Action: No action needed.

* PLUGIN Popper.js API Plugin (popper-api)
    * Description: Correctly installed at version 1.16.1-3
    * Action: No action needed.

* PLUGIN Popper.js 2 API Plugin (popper2-api)
    * Description: Correctly installed at version 2.11.5-2
    * Action: No action needed.

* PLUGIN SAML Plugin (saml)
    * Description: Correctly installed at version 2.298.vc7a_2b_3958628
    * Action: No action needed.

* PLUGIN SCM API Plugin (scm-api)
    * Description: Correctly installed at version 608.vfa_f971c5a_a_e9
    * Action: No action needed.

* PLUGIN Script Security Plugin (script-security)
    * Description: Correctly installed at version 1175.v4b_d517d6db_f0
    * Action: No action needed.

* PLUGIN SnakeYAML API Plugin (snakeyaml-api)
    * Description: Correctly installed at version 1.30.2-76.vc104f7ce9870
    * Action: No action needed.

* PLUGIN SSH Credentials Plugin (ssh-credentials)
    * Description: Correctly installed at version 291.v8211e4f8efb_c
    * Action: No action needed.

* PLUGIN SSH server (sshd)
    * Description: Correctly installed at version 3.237.v883d165a_c1d3
    * Action: No action needed.

* PLUGIN Structs Plugin (structs)
    * Description: Correctly installed at version 318.va_f3ccb_729b_71
    * Action: No action needed.

* PLUGIN Support Core Plugin (support-core)
    * Description: Correctly installed at version 1201.v8d1f54a_6ec7c
    * Action: No action needed.

* PLUGIN Stack Trace Suppression Plugin (deprecated) (suppress-stack-trace)
    * Description: Correctly installed at version 1.6
    * Action: No action needed.

* PLUGIN Token Macro Plugin (token-macro)
    * Description: Correctly installed at version 293.v283932a_0a_b_49
    * Action: No action needed.

* PLUGIN Trilead API Plugin (trilead-api)
    * Description: Correctly installed at version 1.67.vc3938a_35172f
    * Action: No action needed.

* PLUGIN User Activity Monitoring Plugin (user-activity-monitoring)
    * Description: Correctly installed at version 1.7
    * Action: No action needed.

* PLUGIN Variant Plugin (variant)
    * Description: Correctly installed at version 1.4
    * Action: No action needed.

* PLUGIN Pipeline: API (workflow-api)
    * Description: Correctly installed at version 1188.v0016b_4f29881
    * Action: No action needed.

* PLUGIN Pipeline: SCM Step (workflow-scm-step)
    * Description: Correctly installed at version 400.v6b_89a_1317c9a_
    * Action: No action needed.

* PLUGIN Pipeline: Step API (workflow-step-api)
    * Description: Correctly installed at version 625.vd896b_f445a_f8
    * Action: No action needed.

* PLUGIN Pipeline: Supporting APIs (workflow-support)
    * Description: Correctly installed at version 827.v7ef666c4d65c
    * Action: No action needed.

## Plugin Catalog

Not installed
