# Properties

This report contains the Beekeeper related properties that are set to a value different from the default one.

