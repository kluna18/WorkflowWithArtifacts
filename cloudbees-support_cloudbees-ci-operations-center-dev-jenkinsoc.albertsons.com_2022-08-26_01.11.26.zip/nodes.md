Node statistics
===============

  * Total number of nodes
      - Sample size:        52404
      - Average (mean):     0.9999999999999999
      - Average (median):   1.0
      - Standard deviation: 1.1102230246251564E-16
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of nodes online
      - Sample size:        52404
      - Average (mean):     1.0
      - Average (median):   1.0
      - Standard deviation: 0.0
      - Minimum:            1
      - Maximum:            1
      - 95th percentile:    1.0
      - 99th percentile:    1.0
  * Total number of executors
      - Sample size:        52404
      - Average (mean):     2.0000000000000004
      - Average (median):   2.0
      - Standard deviation: 4.440892098500626E-16
      - Minimum:            2
      - Maximum:            2
      - 95th percentile:    2.0
      - 99th percentile:    2.0
  * Total number of executors in use
      - Sample size:        52404
      - Average (mean):     0.0
      - Average (median):   0.0
      - Standard deviation: 0.0
      - Minimum:            0
      - Maximum:            0
      - 95th percentile:    0.0
      - 99th percentile:    0.0

Build Nodes
===========

  * master (Jenkins)
      - Description:    _the Jenkins controller's built-in node_
      - Executors:      2
      - FS root:        `/mnt/nfsocfile/cloudbees-core-oc`
      - Labels:         (none)
      - Usage:          `NORMAL`
      - Marked Offline: false
      - Status:         on-line
      - Slave Version:  4.13.3
      - Java
          + Home:           `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre`
          + Vendor:           Red Hat, Inc.
          + Version:          1.8.0&#95;342
          + Maximum memory:   3.48 GB (3733979136)
          + Allocated memory: 261.00 MB (273678336)
          + Free memory:      38.91 MB (40805240)
          + In-use memory:    222.09 MB (232873096)
          + GC strategy:      ParallelGC
          + Available CPUs:   4
      - Java Runtime Specification
          + Name:    Java Platform API Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Specification
          + Name:    Java Virtual Machine Specification
          + Vendor:  Oracle Corporation
          + Version: 1.8
      - JVM Implementation
          + Name:    OpenJDK 64-Bit Server VM
          + Vendor:  Red Hat, Inc.
          + Version: 25.342-b07
      - Operating system
          + Name:         Linux
          + Architecture: amd64
          + Version:      4.18.0-372.16.1.el8&#95;6.x86&#95;64
      - Process ID: 1706042 (0x1a083a)
      - Process started: 2022-08-16 22:46:32.821+0000
      - Process uptime: 9 days 2 hr
      - JVM startup parameters:
          + Boot classpath: `/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/resources.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/rt.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/sunrsasign.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/jsse.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/jce.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/charsets.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/lib/jfr.jar:/usr/lib/jvm/java-1.8.0-openjdk-1.8.0.342.b07-2.el8_6.x86_64/jre/classes`
          + Classpath: `/usr/lib/cloudbees-core-oc/cloudbees-core-oc.war`
          + Library path: `/usr/java/packages/lib/amd64:/usr/lib64:/lib64:/lib:/usr/lib`
          + arg[0]: `-Dcb.distributable.name=RedHat / Fedora RPM`
          + arg[1]: `-Dcb.distributable.commit_sha=412639d3273d58ef8387e711adb8f9882e47edd4`
          + arg[2]: `-Djava.io.tmpdir=/tmp/tmp.IW4VAWSbJA`
          + arg[3]: `-Djava.awt.headless=true`
          + arg[4]: `-Duser.timezone=America/Los_Angeles`
          + arg[5]: `-Dhudson.TcpSlaveAgentListener.hostName=172.25.35.26`

